import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from "framer-motion";
import axios from 'axios';
import Calendar_view from '../Calendar_view';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendar, faList } from '@fortawesome/free-solid-svg-icons';
import Locations from '../../Components/Locations';
import imageCompression from 'browser-image-compression';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


function Admin_events() {
  const [events, setEvents] = useState([]);
  const apiUrl = 'https://apiafro.aafrodites.com';
  const navigate = useNavigate();

  const [isloaded, setIsloaded] = useState(true);

  const [imagePreview, setImagePreview] = useState(null);
  const [images, setImages] = useState([]);
  const [imagesBoutique, setImagesBoutique] = useState([]);
  const [isnotification, setIsNotification] = useState(false);
  const [imagespath, setImagespath] = useState([]);
  
  

  useEffect(() => {
    const fetchData = async () => {
      try {
        const rep1 = await axios.get(`${apiUrl}/events/all`);
        const formattedEvents = rep1.data.map(event => ({
          ...event,
          date: new Date(event.date).toISOString().split('T')[0],
        }));
        setEvents(formattedEvents);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const toggleModal = () => setIsModalOpen(!isModalOpen);
  const [TypeView, setTypeView] = useState("calendar");
  const handleView = (event) => {
    setTypeView(event.currentTarget.dataset.mode);
  };

  
const [formData, setFormData] = useState({
  name: '',
  eventType: '',
  startDate: '',
  endDate: '',
  startTime: '',
  endTime: '',
  country: '',
  city: '',
  quarter : '',
  locationDescription: '',
  organizer: '',
  expectedParticipants: '',
  status: '',
  visibility: '',
  categories: [],
});

const handleChange = (e) => {
  const { name, value, type, checked } = e.target;
  if (type === 'checkbox') {
    setFormData(prevState => ({
      ...prevState,
      categories: checked
        ? [...new Set([...prevState.categories, value])]  // Utiliser Set pour supprimer les doublons
        : prevState.categories.filter(cat => cat !== value),
    }));    
    console.log(formData)
  } else {
    setFormData(prevState => ({ ...prevState, [name]: value }));
    console.log(formData)

  }
};

const handleLocationChange = (data) => {
  setFormData(prevState => ({
    ...prevState,
    country: data.pays || '',
    city: data.ville || '',
    quarter : data.quartier || '',
  }));
  console.log(formData)
};




const handleImageChange = (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();

    reader.onload = () => {
      const newImagePath = reader.result; // Chemin de la nouvelle image

      
      // Mettre à jour les aperçus
      setImagePreview(newImagePath);
      
 
      // Sauvegarder le chemin dans l'état images
      setImages((prev) => {
        const updatedImages = { ...prev };
        if (!updatedImages.path) {
          updatedImages.path = [];
        }
        updatedImages.path.push(newImagePath); // Ajoute le nouveau chemin
        console.log(updatedImages)
        return updatedImages;
      });
    };
    reader.readAsDataURL(file); // Lit l'image comme DataURL
  }

};


function base64ToFile(base64String, filename) {
    const arr = base64String.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
  
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
  
    return new File([u8arr], filename, { type: mime });
  }
  const compressImage = async (file, maxWidth, maxHeight) => {
    const options = {
      maxWidthOrHeight: Math.max(maxWidth, maxHeight),
      useWebWorker: true,
    };
    return await imageCompression(file, options);
  };

  

  const next_option = async () => {
    console.log("Envoi au serveur...");

    
  
    if (!images?.path || images.path.length === 0) {
      console.error("Aucune image à télécharger");
      return;
    }

    const loadingToastId = toast.info('Traitement de l\'image en cours...', {
      position: "top-center",
      autoClose: false, 
      hideProgressBar: false,
      closeOnClick: false,
      pauseOnHover: false,
      draggable: false,
      progress: undefined,
      theme: "light",
    });
  
    const formData = new FormData();

for (let index = 0; index < images.path.length; index++) {
  const base64Image = images.path[index];
  const originalFileName = `image-${index + 1}.jpeg`;

  // Ajouter un timestamp pour rendre le nom unique
  const timestamp = new Date().toISOString().replace(/[-:.]/g, "");
  const uniqueFileName = `${originalFileName.split(".")[0]}_${timestamp}.jpeg`;

  const file = base64ToFile(base64Image, uniqueFileName);

  // Compression et redimensionnement
  const desktopImage = await compressImage(file, 1920, 1080); // Desktop haute qualité
  const mobileImage = await compressImage(file, 1280, 729); // Mobile haute qualité
  const thumbnailDesktop = await compressImage(file, 600, 400); // Miniature Desktop
  const thumbnailMobile = await compressImage(file, 400, 250); // Miniature Mobile
  

  console.log(desktopImage)
  console.log(mobileImage)
  console.log(thumbnailMobile)
  // Ajout des fichiers compressés avec dossier et type dans FormData
  formData.append("files", file, `${uniqueFileName}_original_desktop`);
  formData.append("folder", "original_resolution");
  formData.append("type", "desktop");

  formData.append("files", desktopImage, `${uniqueFileName}_desktop`);
  formData.append("folder", "haute_resolution");
  formData.append("type", "desktop");

  formData.append("files", mobileImage, `${uniqueFileName}_mobile`);
  formData.append("folder", "haute_resolution");
  formData.append("type", "mobile");

  formData.append("files", thumbnailDesktop, `${uniqueFileName}_thumbnail_desktop`);
  formData.append("folder", "miniatures");
  formData.append("type", "desktop");

  formData.append("files", thumbnailMobile, `${uniqueFileName}_thumbnail_mobile`);
  formData.append("folder", "miniatures");
  formData.append("type", "mobile");
  
}

    try {
     
      const response = await axios.post(`${apiUrl}/uploadfiles/saveFile`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      });

      toast.dismiss(loadingToastId);
      toast.success('Image chargée avec succès !', {
        position: "top-center",
        autoClose: 3000,
        theme: "light",
      });
      
      return response.data?.files;

    } catch (error) {
      toast.dismiss(loadingToastId);
      toast.error('Erreur lors de la mise à jour !', {
      position: "top-center",
      autoClose: 3000,
      theme: "light",
    });
      console.error("Erreur lors de l'upload :", error.response?.data || error.message);
    }
  };
   


  const handleSubmit = async (e) => {
  
      e.preventDefault();
  
   
      const imgs_upld = await next_option(); // Attend que la fonction résolve la promesse
     
      console.log("imgs_upld")
      const all_images = []
         all_images.push({
                              o_desktop : imgs_upld[0] ,
                              hr_desktop : imgs_upld[1] ,
                              hr_mobile : imgs_upld[2] ,
                              m_desktop : imgs_upld[3] ,
                              m_mobile : imgs_upld[4] ,
  
                     });
  
        console.log(all_images)
      // return false;
  
    
  
  
  
      console.log(formData)
  
      
     
      const param = {all_images, formData}
  
      const loadingToast = toast.info('demande en cours...', {
        position: "top-center",
        autoClose: false, // Ne ferme pas la notification automatiquement
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: "light",
      });
          try {
  
            console.log(param)
  
            // return false;
            await axios
              .post(`${apiUrl}/events/add_event`,
                param
                )
              .then((result) => {
          
              console.log("result.data")
                console.log(result)


                
              //   console.log(result.data?.user)
  
              //  return false;
  
              
                  if(result){

                    toast.dismiss(loadingToast);
             
                     
                      toast.success('Evènement ajouté avec Succès' , {
                        position: "top-center",
                        autoClose: 3000,
                        hideProgressBar: true,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                        // transition: Bounce,
                    });
                      
                    setImages([])
                    toggleModal()
                      // setIsloaded(true)
                  
                  
        
                  }
                }); 
                
          } catch (err) {
            console.log("erreur");
            // setError(err.response.data);
          }
    };
  



  return (
    <>
      <div className="admin_datacontent">
          <ToastContainer className="toast_style"/>
        
        {TypeView === "calendar" ? (
          <div className="calendar_view">
            <Calendar_view data={{ list: events }} />
          </div>
        ) : (
          <></>
        )}

        <div className="mode_affichage_container">
          <div className="add_event">
            <button className='add_event_btn' onClick={toggleModal}>+ ajouter</button>
          </div>
          <div className="btn_box">
            {TypeView === "calendar" ? (
              <>
                <button className="view_btn calendar active">
                  <FontAwesomeIcon icon={faCalendar} size='xl' />
                </button>
                <button className="view_btn timeline" data-mode="timelines" onClick={handleView}>
                  <FontAwesomeIcon icon={faList} size='xl' />
                </button>
              </>
            ) : (
              <>
                <button className="view_btn calendar" data-mode="calendar" onClick={handleView}>
                  <FontAwesomeIcon icon={faCalendar} size='xl' />
                </button>
                <button className="view_btn active timeline">
                  <FontAwesomeIcon icon={faList} size='xl' />
                </button>
              </>
            )}
          </div>
        </div>

        <AnimatePresence>
          {isModalOpen && (
            <motion.div className="modal-overlay" onClick={toggleModal} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <motion.div className="modal-content" 
                style={{ maxHeight: "80vh", overflowY: "auto", padding: "20px" }} 
                onClick={(e) => e.stopPropagation()} 
                initial={{ scale: 0.8, opacity: 0 }} 
                animate={{ scale: 1, opacity: 1 }} 
                exit={{ scale: 0.8, opacity: 0 }} 
                transition={{ duration: 0.3, ease: "easeOut" }}>

                <label className='title'>Créer un événement</label>
                <form onSubmit={handleSubmit}>
                  <div className="line_data">
                    <div className="half_col">
                      <input className="input_value" type="text" placeholder="Nom / Titre de l'événement" onChange={handleChange} name='name'/>
                    </div>
                    <div className="half_col item_list location_input col-12">
                      <fieldset>
                          <select className="form-control form-control-lg" onChange={handleChange} name='eventType'>
                            <option value="">Type d'événement</option>
                            <option value="1">Interne</option>
                            <option value="2">Externe</option>
                          </select>
                      </fieldset>
                    </div>

                    <div className="half_col">
                    <input 
                        className="input_value" 
                        type="text" 
                        placeholder="Date Début"
                        onFocus={(e) => e.target.type = "date"} 
                        onBlur={(e) => e.target.type = "text"} 
                        onChange={handleChange}
                        name='startDate'
                      />
                    </div>
                    <div className="half_col">
                    <input 
                        className="input_value" 
                        type="text" 
                        placeholder="Date Fin"
                        onFocus={(e) => e.target.type = "date"} 
                        onBlur={(e) => e.target.type = "text"} 
                        onChange={handleChange}
                        name='endDate'
                      />
                    </div>

                    <div className="half_col">

                    <input 
                      className="input_value" 
                      type="text" 
                      placeholder="Heure Début"
                      onFocus={(e) => e.target.type = "time"} 
                      onBlur={(e) => e.target.type = "text"} 
                      onChange={handleChange}
                      name='startTime'
                    />
                    </div>

                    <div className="half_col">
                    <input 
                      className="input_value" 
                      type="text" 
                      placeholder="Heure Fin"
                      onFocus={(e) => e.target.type = "time"} 
                      onBlur={(e) => e.target.type = "text"} 
                      onChange={handleChange}
                      name='endTime'
                    />
                    </div>

                     <div className="line_data locationbox">
                     <Locations className="inline_zone"
                              inputdata ={{ 
                                          
                                              pays_name : 'pays',

                                              ville_name: 'ville',
                                            //  quartier_name: 'quartier'
                              }} 
                              onChange={handleLocationChange}
                                                                                          
                            />
                      </div>

                    <div className="half_col">
                      <input className="input_value" type="text" placeholder="Description du lieu" name='locationDescription' onChange={handleChange}/>
                    </div>

                     <div className="half_col item_list location_input col-12">
                      <fieldset>
                          <select className="form-control form-control-lg" onChange={handleChange} name='organizer'>
                            <option value="">Organisateur</option>
                            <option value="interne">Interne</option>
                            <option value="externe">Externe</option>
                          </select>
                      </fieldset>
                    </div>

                    <div className="half_col">
                      <input className="input_value" type="text" placeholder="Nombre de participant attendus" onChange={handleChange} name='expectedParticipants'/>
                    </div>

                    <div className="half_col item_list location_input col-12">
                      <fieldset>
                          <select className="form-control form-control-lg" onChange={handleChange} name='status'>
                            <option value="">Status</option>
                            <option value="1">A venir</option>
                            <option value="2">En cours</option>
                            <option value="3">Terminé</option>
                            <option value="4">Annulé</option>
                          </select>
                      </fieldset>
                    </div>

                    <div className="half_col item_list location_input col-12">
                      <fieldset>
                          <select className="form-control form-control-lg" onChange={handleChange} name='visibility'>
                            <option value="">Visibilité</option>
                            <option value="1">Public</option>
                            <option value="2">Privé</option>
                          </select>
                      </fieldset>
                    </div>
                    
                  </div>

                  

                  

                  <div className="line_data">
                  <label>Modèles concernés :</label> <br />
                    <label><input type="checkbox" name="categories" value="1" onChange={handleChange} /> Mannequin</label>
                    <label><input type="checkbox" name="categories" value="2" onChange={handleChange} /> Vlogueuse</label>
                    <label><input type="checkbox" name="categories" value="3" onChange={handleChange} /> Hotesse </label>

                  </div>

                  <div style={styles.formGroup} className='mt-5'>
                        <label style={styles.imageLabel}>
                          {/* Zone de prévisualisation de l'image */}
                          {imagePreview ? (
                            <img
                              src={imagePreview}
                              alt="Prévisualisation"
                              style={styles.imagePreview}
                            />
                          ) : (
                            <span> + image </span>
                          )} 
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageChange}
                            style={styles.fileInput}
                          />
                        </label>
                      </div>

                  <div className="modal-actions flex-center">
                    <button type="submit" className="btn-save">Enregistrer</button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}

const styles = {
  addButton: {
    padding: '10px 20px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  modalOverlay: {
    position: 'fixed',
    zIndex: 999,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '10px',
    width: '400px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    maxHeight: '80vh', 
    overflowY: 'auto'
  },
  formGroup: {
    marginBottom: '15px',
  },
  input: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  textarea: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  submitButton: {
    padding: '4px 8px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    display : 'inline-block'
  },
  closeButton: {
    marginTop: '10px',
    padding: '5px 8px',
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    float: "right",
    // marginRight: "1em",
    display : 'inline-block'
  },
  imageLabel: {
    display: 'block',
    cursor: 'pointer',
    textAlign: 'center',
    padding: '10px',
    border: '1px dashed #ccc',
    borderRadius: '5px',
    backgroundColor: '#f9f9f9',
    position: 'relative',
  },
  fileInput: {
    display: 'none',
  },
  imagePreview: {
    maxWidth: '100%',
    maxHeight: '150px',
    marginBottom: '10px',
  },
};



export default Admin_events;